/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.HashMap;

class TreeNode {
    int val;
    TreeNode left, right;

    TreeNode(int item) {
        val = item;
        left = right = null;
    }
}

public class Main {
    int postIndex;
    HashMap<Integer, Integer> inorderMap = new HashMap<>();

    public TreeNode buildTree(int[] inorder, int[] postorder) {
        postIndex = postorder.length - 1;
        for (int i = 0; i < inorder.length; i++) {
            inorderMap.put(inorder[i], i);
        }

        return build(inorder, postorder, 0, inorder.length - 1);
    }

    private TreeNode build(int[] inorder, int[] postorder, int inStart, int inEnd) {
        if (inStart > inEnd)
            return null;

        int rootVal = postorder[postIndex--];
        TreeNode root = new TreeNode(rootVal);

        if (inStart == inEnd)
            return root;

        int inorderIndex = inorderMap.get(rootVal);

        root.right = build(inorder, postorder, inorderIndex + 1, inEnd);
        root.left = build(inorder, postorder, inStart, inorderIndex - 1);

        return root;
    }
    public void printInorder(TreeNode node) {
        if (node == null) return;
        printInorder(node.left);
        System.out.print(node.val + " ");
        printInorder(node.right);
    }

   public static void main(String[] args) {
    Main treeBuilder = new Main();

    int[] inorder =   {9, 3, 15, 20, 7};
    int[] postorder = {9, 15, 7, 20, 3};

    TreeNode root = treeBuilder.buildTree(inorder, postorder);
    System.out.println("Postorder of constructed tree:");
    treeBuilder.printInorder(root);
   }
}


