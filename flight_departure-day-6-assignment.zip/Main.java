import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

class Flight {
    String flightNumber;
    String destination;

    public Flight(String flightNumber, String destination) {
        this.flightNumber = flightNumber;
        this.destination = destination;
    }

    public String toString() {
        return "Flight " + flightNumber + " to " + destination;
    }
}

public class Main {
    public static void main(String[] args) {
        Queue<Flight> departureQueue = new LinkedList<>();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n ----Flight Departure Queue System----");
            System.out.println("1. Add flight to queue");
            System.out.println("2. Depart flight");
            System.out.println("3. View next flight");
            System.out.println("4. View all flights in queue");
            System.out.println("5. Exit");

            System.out.print("Choose an option: ");
            int choose = scanner.nextInt();
            scanner.nextLine(); 

            switch (choose) {
                case 1:
                    System.out.print("Enter flight number: ");
                    String number = scanner.nextLine();
                    System.out.print("Enter destination: ");
                    String dest = scanner.nextLine();
                    departureQueue.add(new Flight(number, dest));
                    System.out.println("Flight added to queue.");
                    break;

                case 2:
                    Flight departed = departureQueue.poll();
                    if (departed != null) {
                        System.out.println("Departing: " + departed);
                    } else {
                        System.out.println("No flights in the queue.");
                    }
                    break;

                case 3:
                    Flight nextFlight = departureQueue.peek();
                    if (nextFlight != null) {
                        System.out.println("Next flight to depart: " + nextFlight);
                    } else {
                        System.out.println("No flights in the queue.");
                    }
                    break;

                case 4:
                    if (departureQueue.isEmpty()) {
                        System.out.println("No flights in the queue.");
                    } else {
                        System.out.println("Flights in queue:");
                        for (Flight flight : departureQueue) {
                            System.out.println("- " + flight);
                        }
                    }
                    break;

                case 5:
                    System.out.println("Exiting system.");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
