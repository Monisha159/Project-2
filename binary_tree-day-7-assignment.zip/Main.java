
import java.util.*;

class TreeNode {
    int data;
    TreeNode left, right;

    public TreeNode(int value) {
        data = value;
        left = right = null;
    }
}

class ListNode {
    int data;
    ListNode next;

    public ListNode(int value) {
        data = value;
        next = null;
    }
}

public class Main {

    TreeNode root;

    private void inorder(TreeNode node, List<ListNode> list) {
        if (node == null) return;
        inorder(node.left, list);
        list.add(new ListNode(node.data));
        inorder(node.right, list);
    }

    private void preorder(TreeNode node, List<ListNode> list) {
        if (node == null) return;
        list.add(new ListNode(node.data));
        preorder(node.left, list);
        preorder(node.right, list);
    }

    private void postorder(TreeNode node, List<ListNode> list) {
        if (node == null) return;
        postorder(node.left, list);
        postorder(node.right, list);
        list.add(new ListNode(node.data));
    }

    private ListNode buildLinkedList(List<ListNode> nodes) {
        if (nodes.isEmpty()) return null;

        ListNode head = nodes.get(0);
        ListNode current = head;
        for (int i = 1; i < nodes.size(); i++) {
            current.next = nodes.get(i);
            current = current.next;
        }
        return head;
    }

    private void printLinkedList(ListNode head) {
        ListNode current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

   public static void main(String[] args) {
    Main tree = new Main();

    tree.root = new TreeNode(1);
    tree.root.left = new TreeNode(2);
    tree.root.right = new TreeNode(3);
    tree.root.left.left = new TreeNode(4);
    tree.root.left.right = new TreeNode(5);
    tree.root.right.left = new TreeNode(6);
    tree.root.right.right = new TreeNode(7);

    List<ListNode> inorderList = new ArrayList<>();
    List<ListNode> preorderList = new ArrayList<>();
    List<ListNode> postorderList = new ArrayList<>();

    tree.inorder(tree.root, inorderList);
    tree.preorder(tree.root, preorderList);
    tree.postorder(tree.root, postorderList);

    ListNode inorderHead = tree.buildLinkedList(inorderList);
    ListNode preorderHead = tree.buildLinkedList(preorderList);
    ListNode postorderHead = tree.buildLinkedList(postorderList);

    System.out.print("Inorder Linked List: ");
    tree.printLinkedList(inorderHead);

    System.out.print("Preorder Linked List: ");
    tree.printLinkedList(preorderHead);

    System.out.print("Postorder Linked List: ");
    tree.printLinkedList(postorderHead);
   }
}