/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.io.*;
import java.util.*;

class Main {
    public static void printParents(int node, Vector<Vector<Integer>> adj, int parent) {
        if (parent == 0)
            System.out.println(node + " -> Root");
        else
            System.out.println(node + " -> " + parent);

        for (int i = 0; i < adj.get(node).size(); i++) {
            if (adj.get(node).get(i) != parent) {
                printParents(adj.get(node).get(i), adj, node);
            }
        }
    }

    public static void printChildren(int Root, Vector<Vector<Integer>> adj) {
        Queue<Integer> q = new LinkedList<>();
        q.add(Root);

        int vis[] = new int[adj.size()];
        Arrays.fill(vis, 0);

        while (!q.isEmpty()) {
            int node = q.poll();
            vis[node] = 1;
            System.out.print(node + " -> ");

            for (int i = 0; i < adj.get(node).size(); i++) {
                int child = adj.get(node).get(i);
                if (vis[child] == 0) {
                    System.out.print(child + " ");
                    q.add(child);
                }
            }
            System.out.println();
        }
    }

    public static void printLeafNodes(int Root, Vector<Vector<Integer>> adj) {
        for (int i = 1; i < adj.size(); i++) {
            if (adj.get(i).size() == 1 && i != Root)
                System.out.print(i + " ");
        }
        System.out.println();
    }

    public static void printDegrees(int Root, Vector<Vector<Integer>> adj) {
        for (int i = 1; i < adj.size(); i++) {
            System.out.print(i + ": ");
            if (i == Root)
                System.out.println(adj.get(i).size());
            else
                System.out.println(adj.get(i).size() - 1);
        }
    }

    public static void main(String[] args) {
        int N = 7, Root = 1;
        Vector<Vector<Integer>> adj = new Vector<>();
        for (int i = 0; i <= N; i++) {
            adj.add(new Vector<>());
        }

        adj.get(1).add(2);
        adj.get(2).add(1);

        adj.get(1).add(3);
        adj.get(3).add(1);

        adj.get(1).add(4);
        adj.get(4).add(1);

        adj.get(2).add(5);
        adj.get(5).add(2);

        adj.get(2).add(6);
        adj.get(6).add(2);

        adj.get(4).add(7);
        adj.get(7).add(4);

        System.out.println("The parents of each node are:");
        printParents(Root, adj, 0);

        System.out.println("The Children of each node are:");
        printChildren(Root, adj);

        System.out.println("The leaf nodes of the tree are:");
        printLeafNodes(Root, adj);

        System.out.println("The degrees of the tree are:");
        printDegrees(Root, adj);
    }
}
